fx_version 'cerulean'
game 'gta5'
this_is_a_map 'yes'
lua54 'yes'

dependency '/assetpacks'

author "Kreppe"
description "Shell bensionstationer"
version "1.0 Final"
dependency '/assetpacks' 